Citizen.CreateThread(function()
  while true do
    Citizen.Wait(0)
    if IsControlJustPressed(0, 121) then
      TriggerServerEvent('oft_odznaka:odznaka')
      Citizen.Wait(500)
    end
  end
end)

RegisterNetEvent('oft_odznaka:showOdznaka', function(id, imie, nazwisko, stopien)
    local myId = PlayerId()
	local pid = GetPlayerFromServerId(id)
	if pid == myId then
        SendNUIMessage({
            action = 'showODZ',
            imie = imie or "Brak",
            nazwisko = nazwisko or "Brak",
            stopien = stopien or "Nieznany",
        })

        pokazblachaanim()
        blachaprop1()

	elseif #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(GetPlayerPed(pid))) < 7.5 and NetworkIsPlayerActive(pid) then
        SendNUIMessage({
            action = 'showODZ',
            imie = imie or "Brak",
            nazwisko = nazwisko or "Brak",
            stopien = stopien or "Nieznany",
        })

        pokazblachaanim()
        blachaprop1()
	end
end)

function pokazblachaanim()
if not IsPedInAnyVehicle(PlayerPedId(), false) and not IsPedCuffed(PlayerPedId()) then
RequestAnimDict("random@atm_robbery@return_wallet_male")
while (not HasAnimDictLoaded("random@atm_robbery@return_wallet_male")) do Citizen.Wait(0) end
TaskPlayAnim(PlayerPedId(), "random@atm_robbery@return_wallet_male", "return_wallet_positive_a_player", 8.0, 3.0, 1000, 56, 1, false, false, false)
end
end

function blachaprop1()
if not IsPedInAnyVehicle(PlayerPedId(), false) and not IsPedCuffed(PlayerPedId()) then
usuwanieprop()
blacha = CreateObject(GetHashKey('prop_fib_badge'), GetEntityCoords(PlayerPedId()), true)-- creates object
AttachEntityToEntity(blacha, PlayerPedId(), GetPedBoneIndex(PlayerPedId(), 0xDEAD), 0.03, 0.003, -0.065, 90.0, 0.0, 75.0, 1, 0, 0, 0, 0, 1)
Citizen.Wait(1000)
usuwanieprop()
end
end

function usuwanieprop()
DeleteEntity(blacha)
end