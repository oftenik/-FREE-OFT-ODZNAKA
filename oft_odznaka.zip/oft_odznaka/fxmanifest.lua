fx_version 'cerulean'
game 'gta5'

Author 'Oftenik'
Desprection 'oft-odznaka'

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server.lua',
}

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/script.js',
  'html/style.css',
  'html/images/*.png',
}

client_script '@twojloader-opcjonalne/c_loader.lua'
server_script '@twojloader-opcjonalne/s_loader.lua'
my_data 'client_files' { "client.lua" }

lua54 'yes'

shared_script '@es_extended/imports.lua'